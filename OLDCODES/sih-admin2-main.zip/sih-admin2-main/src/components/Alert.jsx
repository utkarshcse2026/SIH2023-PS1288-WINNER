const Alert = ()=>{
  return(
    <nav>
      Alert
    </nav>
  )
}

export default Alert;