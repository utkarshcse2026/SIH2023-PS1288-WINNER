const Services = ()=>{
  return(
    <div className="services">
      <h1> Services & Features - Flow Tech Repairs </h1>
      
    </div>
  )
}

export default Services;