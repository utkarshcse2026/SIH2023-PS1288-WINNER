
const Home = ()=>{
  return(
    <div className="home">
      <div>
         <h1> Welcome to Flow Tech Repair </h1>
        <h4>(Your reliable partner for NRW Management solutions)</h4>

         <p> Around  40% of the water produced in Indian cities does not generate revenue for
         the urban local bodies (ULBs, Shah & Gottipati 2011). The NRW levels significantly 
         affect the per capita water  supply (PCS)and cost recovery (CR) of Indian water supply
         utilities. (Bandari & Sadhukhan 2021) </p>
      </div>
    </div>
  )
}

export default Home;